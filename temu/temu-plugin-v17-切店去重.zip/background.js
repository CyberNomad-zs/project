// Service worker：接收接口数据 → 按【店铺名】分别解析/对比/告警。
// 多店铺：同一账号下有多个店(HomeCove/Twilight Cove/Agnis)，切到哪个店就记哪个店，各自独立快照与告警。
// 数据只存本机 chrome.storage.local，不上传任何服务器。

importScripts('logger.js', 'feishuApp.js');
var log = TemuLogger.createLogger('bg');

// v14：插件只做流量（待关注 / 近期下降）。在售下架点名已迁到服务器赛狐，
// 本开关必须保持 false，避免与 temu-sellfox 双通道重复告警。
// v15：流量只报在售 + 按 productId 冷却去重（下架商品也会挂限流徽标；切店不再刷屏）。
// v16：限流分级（严重 VIP / JM+热销；一般其它）+ 定点差异汇总 + 多维表/任务同步。
// v17：修切店重复告警——stores 读写全局串行，避免 updateStoreLatest 覆盖掉
//      snapshot.alertedTrafficIds；基线必须「非空已告警 ID」，空 {} / 仅 chip 计数不算基线。
const DELIST_IN_PLUGIN = false;

const GOODS_URL = 'https://agentseller.temu.com/goods/list';
const DEFAULT_CONFIG = {
  webhook: '',
  intervalMinutes: 15,
  enabled: true,
  storeName: '',
  // 定时必提醒：每天固定时刻强制发飞书状态汇报（无异常也发，证明插件活着）
  mustRemindEnabled: true,
  mustRemindTimes: ['09:30', '16:30'],
  // 前台变体监测
  frontCheckEnabled: true,
  frontCheckIntervalHours: 3,
  // 飞书企业应用（多维表 + 任务）；本地填写，不进仓库
  feishuAppId: '',
  feishuAppSecret: '',
  bitableAppToken: '',
  bitableTableId: '',
  feishuTaskEnabled: true,
  feishuTasklistGuid: '',
};
const MUST_REMIND_PREFIX = 'mustRemind|';

// ---------------- 解析 ----------------
function parseCountStatus(body) {
  try {
    const j = JSON.parse(body);
    const list = j && j.result && j.result.skcTopStatusCountList;
    if (!Array.isArray(list)) return null;
    const pick = (s) => {
      const x = list.find((e) => e && e.skcTopStatus === s);
      return x && typeof x.skcTotal === 'number' ? x.skcTotal : null;
    };
    return { onSale: pick(100), unpublished: pick(0), removed: pick(200), deleted: pick(300) };
  } catch (e) { log.warn('parseCountStatus: failed to parse response'); return null; }
}
// 从 productSkuSpecList 拼规格名，如「颜色:Khaki / 数量:1pc」→「Khaki」优先单值，多维用「/」
function formatSkuSpecName(sku) {
  const specs = (sku && Array.isArray(sku.productSkuSpecList)) ? sku.productSkuSpecList : null;
  if (specs && specs.length) {
    return specs.map((sp) => String(sp.specName || sp.unitSpecName || '').trim()).filter(Boolean).join('/') || '';
  }
  return String((sku && (sku.specName || sku.skuName || sku.name)) || '').trim();
}
// 把单个 SKU 对象规范成统一结构
function normalizeSku(sku, product) {
  if (!sku || typeof sku !== 'object') return null;
  const skuId = sku.productSkuId || sku.skuId || sku.skuIdStr || sku.id || sku.skuSpecId || '';
  const name = formatSkuSpecName(sku);
  const extCode = String(sku.extCode || sku.skuExtCode || sku.outerSkuId || '').trim();
  if (!skuId && !name && !extCode) return null;
  return {
    skuId: skuId ? String(skuId) : '',
    name: name || extCode || ('SKU' + (skuId ? ' ' + skuId : '')),
    extCode: extCode,
    img: sku.thumbUrl || sku.skuImgUrl || sku.imageUrl || sku.imgUrl || '',
    productId: product && (product.productId || product.productIdStr) ? String(product.productId || product.productIdStr) : '',
    skc: product && (product.productSkcId || product.skcId) ? String(product.productSkcId || product.skcId) : '',
    productName: product && product.productName ? String(product.productName) : '',
    stock: typeof sku.realStock === 'number' ? sku.realStock
      : (typeof sku.virtualStock === 'number' ? sku.virtualStock : null),
  };
}
// 从 pageQuery 商品项提取 SKU 列表（真实字段：productSkuSummaries[].productSkuId + productSkuSpecList）
function extractSkusFromProduct(it) {
  if (!it || typeof it !== 'object') return [];
  const arr = Array.isArray(it.productSkuSummaries) ? it.productSkuSummaries
    : (Array.isArray(it.skuList) ? it.skuList
      : (Array.isArray(it.productSkus) ? it.productSkus : null));
  if (!arr) return [];
  return arr.map((sku) => normalizeSku(sku, it)).filter(Boolean);
}
function parsePageQuery(body) {
  try {
    const j = JSON.parse(body);
    const r = j && j.result;
    if (!r) return null;
    const pageItems = Array.isArray(r.pageItems) ? r.pageItems
      : (Array.isArray(r.list) ? r.list : []);
    const products = [];
    const flatSkus = [];
    for (const it of pageItems) {
      if (!it || typeof it !== 'object') continue;
      const productId = it.productId != null ? String(it.productId) : '';
      if (!productId) continue;
      const skus = extractSkusFromProduct(it);
      // 货号：SKU extCode 优先；商品级 extCode 兜底
      const skuCodes = [];
      const codeSeen = {};
      const pushCode = (c) => {
        const s = String(c || '').trim();
        if (!s) return;
        const k = s.toUpperCase();
        if (codeSeen[k]) return;
        codeSeen[k] = true;
        skuCodes.push(s);
      };
      for (const s of skus) if (s && s.extCode) pushCode(s.extCode);
      if (it.extCode) pushCode(it.extCode);
      const product = {
        productId,
        skc: it.productSkcId != null ? String(it.productSkcId) : '',
        name: String(it.productName || '').slice(0, 80),
        skus,
        skuCount: skus.length,
        skuCodes,
      };
      products.push(product);
      for (const s of skus) flatSkus.push(s);
    }
    return {
      total: typeof r.total === 'number' ? r.total : null,
      products,
      pageSkus: flatSkus,
      pageSkuCount: flatSkus.length,
      multiSkuProducts: products.filter((p) => p.skuCount > 1),
    };
  } catch (e) { log.warn('parsePageQuery: failed to parse response'); return null; }
}
// 在未知 JSON 树里找「看起来像 SKU 列表」的数组（编辑页 parent/list 结构会漂移）
function findSkuLikeArray(node, depth) {
  if (depth > 6 || node == null) return null;
  if (Array.isArray(node)) {
    if (!node.length) return null;
    const sample = node.slice(0, 5).filter((x) => x && typeof x === 'object');
    if (sample.length && sample.every((x) =>
      x.productSkuId != null || x.skuId != null || x.productSkuSpecList != null
      || x.specName != null || x.skuSpecId != null)) {
      return node;
    }
    for (const el of node.slice(0, 20)) {
      const found = findSkuLikeArray(el, depth + 1);
      if (found) return found;
    }
    return null;
  }
  if (typeof node === 'object') {
    // 优先常见键
    for (const k of ['list', 'skuSpecList', 'skuSpecs', 'productSkuSummaries', 'skuList', 'data', 'records', 'items']) {
      if (Array.isArray(node[k])) {
        const found = findSkuLikeArray(node[k], depth + 1);
        if (found) return found;
      }
    }
    for (const k of Object.keys(node).slice(0, 30)) {
      const found = findSkuLikeArray(node[k], depth + 1);
      if (found) return found;
    }
  }
  return null;
}
function parseSkuSpecList(body) {
  try {
    const j = JSON.parse(body);
    // 1) 浅路径 2) 深搜「SKU 形」数组
    let list = j && j.result && j.result.list;
    if (!Array.isArray(list)) list = j && j.result && j.result.skuSpecList;
    if (!Array.isArray(list)) list = j && j.result && j.result.skuSpecs;
    if (!Array.isArray(list)) list = j && j.result && j.result.productSkuSummaries;
    if (!Array.isArray(list)) list = j && j.result && j.result.data;
    if (!Array.isArray(list)) list = j && j.result && Array.isArray(j.result) ? j.result : null;
    if (!Array.isArray(list)) list = j && j.data && j.data.list;
    if (!Array.isArray(list)) list = j && Array.isArray(j.data) ? j.data : null;
    if (!Array.isArray(list)) list = findSkuLikeArray(j, 0);
    if (!Array.isArray(list)) {
      log.warn('parseSkuSpecList: no sku-like array, result keys=' +
        (j && j.result ? Object.keys(j.result).slice(0, 12).join(',') : 'null'));
      chrome.storage.local.set({ lastSkuSpecRawFail: body.slice(0, 3000) });
      return null;
    }
    const specs = list.map((it) => normalizeSku(it, null)).filter(Boolean);
    if (!specs.length) {
      log.warn('parseSkuSpecList: parsed ' + list.length + ' items but none had skuId/name, first item keys=' +
        (list[0] && typeof list[0] === 'object' ? Object.keys(list[0]).slice(0, 12).join(',') : typeof list[0]));
      chrome.storage.local.set({ lastSkuSpecRawFail: body.slice(0, 3000) });
      return null;
    }
    return { skuSpecs: specs, skuSpecCount: specs.length };
  } catch (e) { log.warn('parseSkuSpecList: failed to parse response: ' + (e && e.message ? e.message : String(e))); return null; }
}
function parseSkuPriceQuery(body) {
  try {
    const j = JSON.parse(body);
    const r = j && j.result;
    if (!r) return null;
    // 数据结构未知，先整体保存，后续按需解析
    return { skuPriceRaw: r };
  } catch (e) { log.warn('parseSkuPriceQuery: failed to parse response'); return null; }
}

// ---------------- 存取 ----------------
async function getConfig() {
  const { config } = await chrome.storage.local.get('config');
  return Object.assign({}, DEFAULT_CONFIG, config || {});
}
// 所有 stores 的读-改-写必须走 withStores，否则并发会互相覆盖 snapshot
//（典型：chipStats 的 updateStoreLatest 盖掉 _diffAndAlert 刚写入的 alertedTrafficIds
//  → 切店后再扫同一批限流商品被当成「新出现」重复飞书）。
let storesChain = Promise.resolve();
function withStores(fn) {
  const run = storesChain.then(() => fn());
  // 成功/失败都继续队列，避免一条 rejection 卡死后续写入
  storesChain = run.then(() => {}, () => {});
  return run;
}
async function getStores() {
  const { stores } = await chrome.storage.local.get('stores');
  return stores || {};
}
async function saveStores(stores) {
  await chrome.storage.local.set({ stores });
}
// 更新某店的最新读数（串行）
async function updateStoreLatest(name, patch) {
  return withStores(async () => {
    const stores = await getStores();
    const s = stores[name] || { latest: {}, snapshot: {} };
    s.latest = Object.assign({}, s.latest, patch, { ts: Date.now() });
    stores[name] = s;
    await saveStores(stores);
    return s;
  });
}
// 合并 patch 到 snapshot（串行），供 mustRemind / sku diff 等使用
async function updateStoreSnapshot(name, snapPatch) {
  return withStores(async () => {
    const stores = await getStores();
    const s = stores[name] || { latest: {}, snapshot: {} };
    s.snapshot = Object.assign({}, s.snapshot || {}, snapPatch);
    stores[name] = s;
    await saveStores(stores);
    return s;
  });
}
// alerted map 是否已有有效基线（空 {} 不算——否则首次空池 seed 后，明细一出现会全量误报）
function alertedMapSize(map) {
  return map && typeof map === 'object' ? Object.keys(map).length : 0;
}
function hasTrafficBaseline(snap) {
  if (!snap || typeof snap !== 'object') return false;
  if (snap.trafficBaselineAt) return true;
  return alertedMapSize(snap.alertedTrafficIds)
    + alertedMapSize(snap.alertedWatchIds)
    + alertedMapSize(snap.alertedDeclineIds) > 0;
}

// ---------------- 飞书 ----------------
// template：飞书卡片色条 red/orange/blue/green/turquoise/wathet/purple/violet/carmine/yellow/grey
async function sendFeishu(webhook, title, lines, template) {
  if (!webhook) return { ok: false, msg: '未配置飞书 webhook' };
  const card = {
    msg_type: 'interactive',
    card: {
      header: { title: { tag: 'plain_text', content: title }, template: template || 'red' },
      elements: [{ tag: 'div', text: { tag: 'lark_md', content: lines.join('\n') } }],
    },
  };
  try {
    const resp = await fetch(webhook, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(card) });
    const data = await resp.json().catch(() => ({}));
    const ok = resp.ok && (data.code === 0 || data.StatusCode === 0 || data.code === undefined);
    if (ok) log.info('Feishu sent OK: ' + title);
    return { ok, msg: ok ? '已发送' : ('飞书返回：' + JSON.stringify(data)) };
  } catch (e) {
    log.error('Feishu send FAILED: ' + (e && e.message ? e.message : 'unknown'));
    return { ok: false, msg: '发送失败：' + (e && e.message) };
  }
}

// ---------------- 定时必提醒（每天固定时刻强制汇报各店状态） ----------------
function parseHHMM(s) {
  const m = String(s || '').trim().match(/^(\d{1,2})[:.：](\d{2})$/);
  if (!m) return null;
  const h = Number(m[1]);
  const min = Number(m[2]);
  if (h > 23 || min > 59) return null;
  return { h, min, label: String(h).padStart(2, '0') + ':' + String(min).padStart(2, '0') };
}
// 下一次触发时间戳（本地时区）；若今天该时刻已过（或 5 秒内），排到明天
function nextWhen(hhmm) {
  const p = parseHHMM(hhmm);
  if (!p) return null;
  const now = new Date();
  const t = new Date(now.getFullYear(), now.getMonth(), now.getDate(), p.h, p.min, 0, 0);
  if (t.getTime() <= now.getTime() + 5000) t.setDate(t.getDate() + 1);
  return t.getTime();
}
function fmtNum(v) { return typeof v === 'number' ? String(v) : '—'; }
async function sendMustRemind(slot) {
  const cfg = await getConfig();
  if (!cfg.enabled || cfg.mustRemindEnabled === false) {
    log.info('MustRemind skipped: disabled');
    return { ok: false, msg: '未启用' };
  }
  if (!cfg.webhook) {
    log.warn('MustRemind skipped: no webhook');
    return { ok: false, msg: '未配置飞书 webhook' };
  }
  const stores = await getStores();
  const names = Object.keys(stores).sort();
  const lines = [
    '**定时必提醒' + (slot ? ' · ' + slot : '') + '**',
    '_存活汇报 + 限流差异（相对上一固定时点）_',
    '',
  ];
  const allDiffItems = []; // { store, item, change } change=added|upgraded|removed
  let anyDiff = false;

  if (!names.length) {
    lines.push('_暂无店铺数据。请打开 goods/list 或点「轮巡所有店」。_');
  } else {
    for (const name of names) {
      const s = stores[name] || {};
      const L = s.latest || {};
      const snap = s.snapshot || {};
      const stale = L.ts && (Date.now() - L.ts > 2 * 60 * 60 * 1000);
      const pool = buildTrafficPool(L);
      const currMap = {};
      for (const it of pool) {
        currMap[String(it.productId)] = {
          severity: it.severity,
          name: it.name,
          skc: it.skc,
          skuCodes: it.skuCodes,
          hotSale: it.hotSale,
          kinds: it.kinds,
          reason: it.reason,
          productId: it.productId,
        };
      }
      const prevMap = snap.slotTrafficMap || {};
      const added = [];
      const upgraded = [];
      const removed = [];
      for (const pid of Object.keys(currMap)) {
        if (!prevMap[pid]) added.push(currMap[pid]);
        else if (prevMap[pid].severity !== 'severe' && currMap[pid].severity === 'severe') {
          upgraded.push(currMap[pid]);
        }
      }
      for (const pid of Object.keys(prevMap)) {
        if (!currMap[pid]) removed.push(Object.assign({ productId: pid }, prevMap[pid]));
      }
      const storeDiff = added.length + upgraded.length + removed.length;
      if (storeDiff) anyDiff = true;

      lines.push('**🏬 ' + name + '**' + (stale ? ' ⚠️数据超过2小时未更新' : ''));
      lines.push(
        '在售 **' + fmtNum(L.onSale) + '**'
        + ' · 待关注 **' + fmtNum(L.trafficWatch) + '**'
        + ' · 下降 **' + fmtNum(L.trafficDecline) + '**'
        + ' · 限流池 **' + pool.length + '**'
        + '（严重 ' + pool.filter((p) => p.severity === 'severe').length
        + ' / 一般 ' + pool.filter((p) => p.severity !== 'severe').length + '）'
      );
      if (!Object.keys(prevMap).length) {
        lines.push('_本时点建立限流基准 ' + pool.length + ' 条，不报差异_');
      } else if (!storeDiff) {
        lines.push('_限流无变化_');
      } else {
        if (added.length) {
          lines.push('新增限流 **' + added.length + '**：');
          lines.push(...itemLines(added, added.length));
          for (const it of added) allDiffItems.push({ store: name, item: it, change: 'added' });
        }
        if (upgraded.length) {
          lines.push('升级为严重 **' + upgraded.length + '**：');
          lines.push(...itemLines(upgraded, upgraded.length));
          for (const it of upgraded) allDiffItems.push({ store: name, item: it, change: 'upgraded' });
        }
        if (removed.length) {
          lines.push('解除/不再见 **' + removed.length + '**：');
          for (const it of removed.slice(0, 8)) {
            lines.push('• ~~' + String(it.name || it.productId).slice(0, 28) + '~~  SKC ' + (it.skc || '-'));
          }
          if (removed.length > 8) lines.push('_…另有 ' + (removed.length - 8) + ' 条_');
        }
      }
      lines.push('上次检查：' + (L.ts ? new Date(L.ts).toLocaleString('zh-CN') : '—'));
      lines.push('');

      // 写回 slotTrafficMap（走串行队列，避免盖掉即时告警的 alertedTrafficIds）
      await updateStoreSnapshot(name, { slotTrafficMap: currMap, slotTrafficMapTs: Date.now() });
    }
  }

  const lastCycle = (await chrome.storage.local.get('lastCycle')).lastCycle;
  if (lastCycle && lastCycle.ts) {
    lines.push('上次轮巡：' + new Date(lastCycle.ts).toLocaleString('zh-CN'));
  }
  lines.push('_汇报时间：' + new Date().toLocaleString('zh-CN') + '_');

  // 有差异用橙/红，无差异用蓝存活
  const hasSevereDiff = allDiffItems.some((d) => d.item && d.item.severity === 'severe');
  const template = anyDiff ? (hasSevereDiff ? 'red' : 'orange') : 'blue';
  const title = anyDiff
    ? ('🔔 Temu 限流定点汇总' + (slot ? ' · ' + slot : ''))
    : ('📋 Temu 监测定时汇报' + (slot ? ' · ' + slot : ''));
  const r = await sendFeishu(cfg.webhook, title, lines, template);

  // 差异条目同步多维表 + 严重任务
  if (anyDiff && typeof FeishuApp !== 'undefined') {
    const byStore = {};
    for (const d of allDiffItems) {
      if (d.change === 'removed') continue;
      if (!byStore[d.store]) byStore[d.store] = [];
      byStore[d.store].push(d.item);
    }
    for (const storeName of Object.keys(byStore)) {
      try {
        await FeishuApp.syncAfterAlert(cfg, storeName, byStore[storeName]);
      } catch (e) {
        log.warn('MustRemind FeishuApp: ' + ((e && e.message) || e));
      }
    }
  }

  await chrome.storage.local.set({
    lastMustRemind: {
      ts: Date.now(), ok: r.ok, msg: r.msg, slot: slot || '',
      anyDiff: anyDiff, diffCount: allDiffItems.length,
    },
  });
  log.info('MustRemind done: slot=' + (slot || '') + ' ok=' + r.ok + ' anyDiff=' + anyDiff);
  return r;
}
async function setupMustRemindAlarms() {
  const all = await chrome.alarms.getAll();
  for (const a of all) {
    if (a.name.startsWith(MUST_REMIND_PREFIX)) await chrome.alarms.clear(a.name);
  }
  const cfg = await getConfig();
  if (cfg.mustRemindEnabled === false) {
    log.info('MustRemind alarms cleared (disabled)');
    return;
  }
  const raw = Array.isArray(cfg.mustRemindTimes) && cfg.mustRemindTimes.length
    ? cfg.mustRemindTimes
    : DEFAULT_CONFIG.mustRemindTimes;
  const seen = {};
  for (const t of raw) {
    const p = parseHHMM(t);
    if (!p || seen[p.label]) continue;
    seen[p.label] = true;
    const when = nextWhen(p.label);
    if (!when) continue;
    chrome.alarms.create(MUST_REMIND_PREFIX + p.label, { when });
    log.info('MustRemind alarm set: ' + p.label + ' → ' + new Date(when).toLocaleString('zh-CN'));
  }
}

// ---------------- 商品明细 → 带链接的告警行 ----------------
// 后台商品操作都是弹窗、无深链，唯一稳定可点的是编辑页（实测格式：SPU ID 即 productId）。
function editLink(productId) {
  return 'https://agentseller.temu.com/goods/edit?from=productList&productId=' + productId;
}

// v16：限流分级
// 严重：SKU货号 VIP*（自有） 或 （JM* 且 热销款=黑猫）
// 一般：有限流但不满足严重
function classifySeverity(item) {
  const codes = Array.isArray(item && item.skuCodes) ? item.skuCodes : [];
  const hot = !!(item && item.hotSale);
  let hasVip = false;
  let hasJm = false;
  for (const c of codes) {
    const s = String(c || '').trim();
    if (/^VIP/i.test(s)) hasVip = true;
    if (/^JM/i.test(s)) hasJm = true;
  }
  if (hasVip) return { severity: 'severe', reason: '自有VIP' };
  if (hasJm && hot) return { severity: 'severe', reason: '黑猫JM+热销款' };
  return { severity: 'general', reason: '其它限流' };
}

function mergeSkuCodes() {
  const out = [];
  const seen = {};
  for (let i = 0; i < arguments.length; i++) {
    const arr = arguments[i];
    if (!Array.isArray(arr)) continue;
    for (const c of arr) {
      const s = String(c || '').trim();
      if (!s) continue;
      const k = s.toUpperCase();
      if (seen[k]) continue;
      seen[k] = true;
      out.push(s);
    }
  }
  return out;
}

// 用 pageQuery 缓存的 extCode 补全 DOM 条目的货号
function enrichWithPageCodes(items, productSkuCodeMap) {
  const map = productSkuCodeMap || {};
  return (items || []).map((it) => {
    if (!it) return it;
    const fromPage = map[String(it.productId)] || [];
    return Object.assign({}, it, {
      skuCodes: mergeSkuCodes(it.skuCodes, fromPage),
    });
  });
}

function buildProductSkuCodeMap(pageProducts) {
  const map = {};
  for (const p of pageProducts || []) {
    if (!p || !p.productId) continue;
    map[String(p.productId)] = Array.isArray(p.skuCodes) ? p.skuCodes.slice() : [];
  }
  return map;
}

// 合并 watch + decline 为在售限流池，附 kinds / severity
function buildTrafficPool(latest) {
  const byId = {};
  const codeMap = latest && latest.productSkuCodeMap ? latest.productSkuCodeMap : {};
  const absorb = (list, kind) => {
    for (const raw of list || []) {
      if (!raw || !raw.productId) continue;
      if (raw.saleStatus === 'removed') continue;
      // 被动扫要求 onSale；主动扫已标 onSale
      if (raw.saleStatus && raw.saleStatus !== 'onSale' && raw.saleStatus !== 'unknown') continue;
      const pid = String(raw.productId);
      const prev = byId[pid] || {
        productId: pid,
        name: raw.name || '',
        skc: raw.skc || '',
        skuCodes: [],
        hotSale: false,
        kinds: [],
        saleStatus: raw.saleStatus || 'onSale',
      };
      prev.name = raw.name || prev.name;
      prev.skc = raw.skc || prev.skc;
      prev.skuCodes = mergeSkuCodes(prev.skuCodes, raw.skuCodes, codeMap[pid]);
      prev.hotSale = prev.hotSale || !!raw.hotSale;
      if (prev.kinds.indexOf(kind) < 0) prev.kinds.push(kind);
      if (raw.saleStatus === 'onSale') prev.saleStatus = 'onSale';
      byId[pid] = prev;
    }
  };
  absorb(latest && latest.watchItems, 'watch');
  absorb(latest && latest.declineItems, 'decline');
  const pool = [];
  for (const pid of Object.keys(byId)) {
    const it = byId[pid];
    // unknown 且无任何限流 kind 不应出现；有 kind 则保留（主动扫可能 unknown→已标 onSale）
    if (it.saleStatus === 'removed') continue;
    if (it.saleStatus === 'unknown' && !(it.kinds && it.kinds.length)) continue;
    // 严格：被动 unknown 可能是下架误读——若只有 decline/watch 但 status unknown，仍排除
    // 例外：主动 scan 已写 onSale
    if (it.saleStatus !== 'onSale') continue;
    const cls = classifySeverity(it);
    it.severity = cls.severity;
    it.reason = cls.reason;
    pool.push(it);
  }
  // 严重优先
  pool.sort((a, b) => {
    if (a.severity !== b.severity) return a.severity === 'severe' ? -1 : 1;
    return String(a.name || '').localeCompare(String(b.name || ''), 'zh');
  });
  return pool;
}

// items：限流商品；带 severity 时行首加红/橙标记
function itemLines(items, total) {
  const lines = [];
  if (Array.isArray(items) && items.length) {
    for (const it of items) {
      const nm = String(it.name || '商品').replace(/[[\]]/g, '').slice(0, 28);
      const sev = it.severity === 'severe' ? '🔴' : (it.severity === 'general' ? '🟠' : '•');
      const codeStr = (it.skuCodes && it.skuCodes.length)
        ? '  货号 ' + it.skuCodes.slice(0, 3).join('/')
        : '';
      const reason = it.reason ? '  _' + it.reason + '_' : '';
      const hot = it.hotSale ? ' 🔥' : '';
      lines.push(sev + ' [' + nm + '](' + editLink(it.productId) + ')  SKC ' + (it.skc || '-') + codeStr + hot + reason);
    }
    if (typeof total === 'number' && total > items.length) {
      lines.push('_（本页可见 ' + items.length + ' 条，共 ' + total + ' 条，其余在其它页；点「商品流量待关注」筛选可看全）_');
    }
  } else if (typeof total === 'number' && total > 0) {
    lines.push('_（当前页未显示具体商品，共 ' + total + ' 条；打开「商品流量待关注」筛选可查看）_');
  }
  return lines;
}

// 让 content.js 主动点「商品流量待关注」筛选，捞出这几条被限流的具体商品（productId+name+skc）
async function scanWatchViaTab() {
  const tab = await getGoodsTab();
  if (!tab) return null;
  return await sendTabRetry(tab.id, { cmd: 'scanWatchList' }, 3);
}

// ---------------- 对比 & 告警（按店） ----------------
// 按店串行：同一店的多条读数消息（切店时常一秒内来两条）排队逐个处理，
// 避免"都读到旧快照各报一次"的竞态导致同一事件重复告警。
const alertChains = {};
// v15：同一商品冷却期内不重复告警。切店/翻页会让「本页可见 decline 数」在 0↔1 抖动，
// 旧版按计数上升触发 → 一切店就再推一次。改成按 productId 去重。
const ALERT_COOLDOWN_MS = 6 * 60 * 60 * 1000; // 6 小时
function pruneAlertedMap(map, now) {
  const out = {};
  const keepFor = ALERT_COOLDOWN_MS * 4; // 保留 24h 历史，便于排障
  for (const id of Object.keys(map || {})) {
    const ts = map[id];
    if (typeof ts === 'number' && now - ts < keepFor) out[id] = ts;
  }
  return out;
}
// 从 items 里挑出冷却期外、尚未报过的新 productId
function pickFreshItems(items, alertedMap, now) {
  const fresh = [];
  const seen = {};
  for (const it of items || []) {
    if (!it || !it.productId) continue;
    const pid = String(it.productId);
    if (seen[pid]) continue;
    seen[pid] = true;
    const last = alertedMap && alertedMap[pid];
    if (typeof last === 'number' && now - last < ALERT_COOLDOWN_MS) continue;
    fresh.push(it);
  }
  return fresh;
}
function markAlerted(alertedMap, items, now) {
  const out = Object.assign({}, alertedMap || {});
  for (const it of items || []) {
    if (it && it.productId) out[String(it.productId)] = now;
  }
  return out;
}
function diffAndAlert(name) {
  const prev = alertChains[name] || Promise.resolve();
  const next = prev.then(() => _diffAndAlert(name)).catch(() => {});
  alertChains[name] = next;
  return next;
}

async function _diffAndAlert(name) {
  const cfg = await getConfig();
  if (!cfg.enabled) return;

  // 先在串行锁外做主动扫（可能点 tab，耗时长），避免长时间占住 stores 队列
  let preScanItems = null;
  {
    const storesPeek = await getStores();
    const sPeek = storesPeek[name];
    if (!sPeek) return;
    const latestPeek = sPeek.latest || {};
    const snapPeek = sPeek.snapshot || {};
    const watchCountUpPeek = typeof snapPeek.trafficWatch === 'number'
      && typeof latestPeek.trafficWatch === 'number'
      && latestPeek.trafficWatch > snapPeek.trafficWatch;
    if (watchCountUpPeek) {
      const scan = await scanWatchViaTab();
      if (scan && scan.applied && Array.isArray(scan.items) && scan.items.length) {
        preScanItems = scan.items;
      }
    }
  }

  // 读 latest + 判定 + 写 snapshot 整段串行，杜绝与 updateStoreLatest 交叉覆盖
  const result = await withStores(async () => {
    const stores = await getStores();
    const s = stores[name];
    if (!s) return null;
    let latest = s.latest || {};
    const snap = s.snapshot || {};
    const now = Date.now();
    // v16：统一用 alertedTrafficIds（兼容读旧 alertedWatch/Decline）
    let alerted = pruneAlertedMap(
      Object.assign({}, snap.alertedWatchIds || {}, snap.alertedDeclineIds || {}, snap.alertedTrafficIds || {}),
      now
    );

    // 在售数量下降：v14 起关闭
    // ---- 限流池（在售 ∩ 待关注/下降）分级 ----
    const watchCountUp = typeof snap.trafficWatch === 'number'
      && typeof latest.trafficWatch === 'number'
      && latest.trafficWatch > snap.trafficWatch;

    // 合并主动扫明细进 latest（同一锁内写回，防止丢失）
    if (preScanItems && preScanItems.length) {
      const mergedWatch = {};
      for (const it of (latest.watchItems || []).concat(preScanItems)) {
        if (it && it.productId) mergedWatch[String(it.productId)] = it;
      }
      latest = Object.assign({}, latest, { watchItems: Object.keys(mergedWatch).map((k) => mergedWatch[k]), ts: Date.now() });
      s.latest = latest;
    }

    // 合并：若本轮 items 为空但上次 latest 仍有同店明细，保留旧明细
    // （切店瞬间表格未渲染完会先上报空数组，不能用空覆盖已有限流清单）
    // 注意：这里 latest 已是 storage 最新值；chipStats 侧也会做 merge。

    const pool = buildTrafficPool(latest);
    // v17：基线 = 已 seed 过至少一次有效 alerted ID，或显式 trafficBaselineAt。
    // 旧逻辑把空 {} / 仅 trafficWatch 数字也当 ready → 切店后全量当「新增」误报。
    const baselineReady = hasTrafficBaseline(snap);

    let fresh = [];
    let seeded = false;
    if (!baselineReady) {
      // 首次只 seed 不告警。pool 为空时不建基线（等表格渲染出明细再 seed），
      // 否则空 seed + trafficBaselineAt 会让稍后出现的同一批商品全量误报。
      if (pool.length > 0) {
        alerted = markAlerted(alerted, pool, now);
        seeded = true;
        log.info('Traffic baseline seeded: store=' + name + ' known=' + Object.keys(alerted).length
          + ' pool=' + pool.length);
      } else {
        log.info('Traffic baseline deferred: store=' + name + ' pool empty (wait items)');
      }
    } else {
      fresh = pickFreshItems(pool, alerted, now);
      // 冷却内但等级从 general→severe 的，也要再报一次（升级）
      for (const it of pool) {
        if (!it || it.severity !== 'severe') continue;
        const pid = String(it.productId);
        if (fresh.some((f) => String(f.productId) === pid)) continue;
        const prevSev = (snap.trafficSeverityMap && snap.trafficSeverityMap[pid]) || '';
        if (prevSev && prevSev !== 'severe') {
          fresh.push(it);
        }
      }
      if (fresh.length) {
        alerted = markAlerted(alerted, fresh, now);
      } else if (watchCountUp) {
        log.info('Watch chip rose but no fresh traffic items: store=' + name
          + ' chip=' + snap.trafficWatch + '→' + latest.trafficWatch + ' pool=' + pool.length);
      }
    }

    // 写回快照（同一锁内，latest 若被合并也一起存）
    const newSnap = Object.assign({}, snap);
    if (typeof latest.onSale === 'number') newSnap.onSale = latest.onSale;
    if (typeof latest.total === 'number') newSnap.total = latest.total;
    if (typeof latest.trafficWatch === 'number') newSnap.trafficWatch = latest.trafficWatch;
    if (typeof latest.trafficDecline === 'number') newSnap.trafficDecline = latest.trafficDecline;
    newSnap.alertedTrafficIds = alerted;
    newSnap.alertedWatchIds = alerted;
    newSnap.alertedDeclineIds = alerted;
    // 仅在真正 seed 过（或旧数据已有非空 alerted）时打基线时间戳
    if (seeded) newSnap.trafficBaselineAt = now;
    else if (!newSnap.trafficBaselineAt && alertedMapSize(alerted) > 0) newSnap.trafficBaselineAt = snap.trafficBaselineAt || now;
    const sevMap = Object.assign({}, newSnap.trafficSeverityMap || {});
    for (const it of pool) {
      if (it && it.productId) sevMap[String(it.productId)] = it.severity;
    }
    newSnap.trafficSeverityMap = sevMap;
    newSnap.ts = Date.now();
    s.snapshot = newSnap;
    s.latest = latest;
    stores[name] = s;
    await saveStores(stores);
    log.info('Snapshot updated: store=' + name
      + ' alerted=' + Object.keys(alerted).length
      + ' pool=' + pool.length
      + ' fresh=' + fresh.length
      + ' baseline=' + (baselineReady || seeded));
    return { fresh: fresh.slice(), watchCountUp: watchCountUp, poolSize: pool.length };
  });

  if (!result || !result.fresh || !result.fresh.length) return;

  const fresh = result.fresh;
  const severe = fresh.filter((i) => i.severity === 'severe');
  const general = fresh.filter((i) => i.severity !== 'severe');
  const lines = ['**🏬 ' + name + '**'];
  if (severe.length) {
    lines.push('**🔴 严重限流 ' + severe.length + ' 个**（自有VIP / 黑猫JM+热销款）');
    lines.push(...itemLines(severe, severe.length));
  }
  if (general.length) {
    lines.push('**🟠 一般限流 ' + general.length + ' 个**');
    lines.push(...itemLines(general, general.length));
  }
  lines.push('', '_检查时间：' + new Date().toLocaleString('zh-CN') + '_');
  const template = severe.length ? 'red' : 'orange';
  log.info('Alert triggered: store=' + name + ' severe=' + severe.length + ' general=' + general.length);
  const r = await sendFeishu(cfg.webhook, '🔔 Temu 限流告警', lines, template);
  await chrome.storage.local.set({
    lastAlert: { ts: Date.now(), ok: r.ok, msg: r.msg, store: name, lines, severe: severe.length, general: general.length },
  });
  try {
    if (typeof FeishuApp !== 'undefined') {
      await FeishuApp.syncAfterAlert(cfg, name, fresh);
    }
  } catch (e) {
    log.warn('FeishuApp sync: ' + ((e && e.message) || e));
  }
}

// pageQuery 同商品 SKU 消失检测。
// 只对比「本轮 pageQuery 里再次出现的 productId」——当前页以外的商品本轮没看到，绝不判下架。
// 首轮只建 snapshot.productSkuMap，不告警。
async function diffProductSkus(name, products) {
  if (!Array.isArray(products) || !products.length) return 0;
  const cfg = await getConfig();
  const stores = await getStores();
  const s = stores[name] || { latest: {}, snapshot: {} };
  const prevMap = (s.snapshot && s.snapshot.productSkuMap) || {};
  const nextMap = Object.assign({}, prevMap);
  const removed = []; // { productId, productName, skc, skuId, name }
  let compared = 0;

  for (const p of products) {
    if (!p || !p.productId) continue;
    const pid = String(p.productId);
    const currSkus = Array.isArray(p.skus) ? p.skus : [];
    // 当前商品在本页出现但 SKU 列表空：可能接口字段漂移/截断，跳过该商品、保留旧基准
    if (!currSkus.length) continue;
    const currById = {};
    for (const sk of currSkus) {
      if (sk && sk.skuId) currById[String(sk.skuId)] = sk;
    }
    const prev = prevMap[pid];
    if (prev && prev.skus && typeof prev.skus === 'object') {
      compared += 1;
      for (const skuId of Object.keys(prev.skus)) {
        if (!currById[skuId]) {
          const old = prev.skus[skuId] || {};
          removed.push({
            productId: pid,
            productName: p.name || prev.name || '',
            skc: p.skc || prev.skc || '',
            skuId,
            name: old.name || skuId,
          });
        }
      }
    }
    // 更新该 product 的 SKU 基准（只记 id→name）
    const skusObj = {};
    for (const sk of currSkus) {
      if (sk && sk.skuId) skusObj[String(sk.skuId)] = { name: sk.name || '', img: sk.img || '' };
    }
    nextMap[pid] = {
      name: p.name || (prev && prev.name) || '',
      skc: p.skc || (prev && prev.skc) || '',
      skus: skusObj,
      ts: Date.now(),
    };
  }

  // 写回快照（合并式：本页商品更新，其它页旧基准保留；串行避免盖掉 alerted）
  await updateStoreSnapshot(name, { productSkuMap: nextMap });

  if (!removed.length) {
    if (compared) log.info('diffProductSkus: store=' + name + ' compared=' + compared + ' removed=0');
    return 0;
  }

  log.info('diffProductSkus: store=' + name + ' compared=' + compared + ' removed=' + removed.length);
  if (!cfg.enabled) return removed.length;

  const lines = [
    '**🏬 ' + name + '**',
    '📦 后台检测到 SKU 规格消失 **' + removed.length + '** 个（同商品内对比，非整 SKC 下架）',
    '',
  ];
  // 按商品分组展示
  const byProduct = {};
  for (const r of removed) {
    const k = r.productId;
    if (!byProduct[k]) byProduct[k] = { productId: k, productName: r.productName, skc: r.skc, skus: [] };
    byProduct[k].skus.push(r);
  }
  for (const g of Object.values(byProduct)) {
    const nm = String(g.productName || '商品').replace(/[[\]]/g, '').slice(0, 30);
    lines.push('• [' + nm + '](' + editLink(g.productId) + ')' + (g.skc ? '  SKC ' + g.skc : ''));
    for (const sk of g.skus) {
      lines.push('   ❌ ' + (sk.name || sk.skuId) + '  (skuId ' + sk.skuId + ')');
    }
  }
  lines.push('');
  lines.push('_说明：对比来源 = 商品列表 pageQuery 的 productSkuSummaries；仅对「本页再次出现的商品」做 SKU 集合 diff，避免分页误报。_');
  lines.push('_检查时间：' + new Date().toLocaleString('zh-CN') + '_');
  const fr = await sendFeishu(cfg.webhook, '🔔 Temu SKU 规格消失', lines, 'orange');
  await chrome.storage.local.set({
    lastAlert: { ts: Date.now(), ok: fr.ok, msg: fr.msg, store: name, kind: 'skuRemoved', lines },
  });
  return removed.length;
}

// 在售清单 diff：找出「上一轮在售、这一轮不在」的商品 = 下架/移出在售，带商品名+编辑链接告警。
// items 为 content.js 扫「在售中」tab 得到的当前在售商品(productId+name+skc)。返回下架数量(供日志)。
// scanStore 为扫描瞬间页面实际所在店：与 name 不符 = 切店竞态（这批是别店数据）→ 整轮作废。
async function diffOnSale(name, items, onSaleTabCount, scanStore) {
  // v14：下架点名已迁服务器，插件内默认不跑
  if (!DELIST_IN_PLUGIN) return 0;
  if (!Array.isArray(items) || !items.length) return 0; // 空 = 扫描失败或真 0，稳妥起见不动基准、不报
  if (scanStore && scanStore !== name) { log.warn('onSale scan store mismatch: want=' + name + ' got=' + scanStore + '，本轮作废'); return 0; }
  const cfg = await getConfig();
  const stores = await getStores();
  const s = stores[name] || { latest: {}, snapshot: {} };
  // 防残缺扫描/筛选污染误判：以"扫描当时在干净视图下读到的「在售中 N」"为权威在售数
  // （content.js scanOnSaleList 复位后读的，不会被「商品流量待关注」筛选污染）；
  // 读不到才回退 countStatus 的 latest.onSale。扫到的商品数必须恰好等于它：
  //   少了 = 没扫全/分页 → 跳过；多了 = 视图污染（全部/未发布/别店商品混入，可能含从未上架商品）→ 跳过。
  //   旧版只查"少"不查"多"，曾放过 20 条污染扫描（在售实为 13）写进基准，
  //   下一轮干净扫描引爆「下架15个(在售20→13)」假告警。
  const known = (typeof onSaleTabCount === 'number' && onSaleTabCount > 0)
    ? onSaleTabCount
    : (s.latest && typeof s.latest.onSale === 'number' ? s.latest.onSale : null);
  if (known != null && items.length < known) { log.warn('onSale scan incomplete: store=' + name + ' scanned=' + items.length + ' known=' + known); return 0; }
  if (known != null && items.length > known) { log.warn('onSale scan overflow: store=' + name + ' scanned=' + items.length + ' known=' + known + '，疑似视图污染，本轮作废'); return 0; }
  const newMap = {};
  for (const it of items) if (it && it.productId) newMap[it.productId] = { name: it.name || '', skc: it.skc || '' };
  const prevMap = s.snapshot && s.snapshot.onSaleIds;
  let delistedCount = 0;
  if (prevMap && cfg.enabled) { // 首次无基准 → 只记录不报
    const delisted = Object.keys(prevMap).filter((pid) => !(pid in newMap));
    delistedCount = delisted.length;
    if (delisted.length) {
      const added = Object.keys(newMap).filter((pid) => !(pid in prevMap)).length;
      log.warn('Delisted items: store=' + name + ' count=' + delisted.length + ' onSale=' + Object.keys(prevMap).length + '→' + items.length + ' added=' + added);
      const its = delisted.map((pid) => ({ productId: pid, name: prevMap[pid].name, skc: prevMap[pid].skc }));
      // 「在售 A → B」的差值 ≠ 下架数（同期可能有新品上架）；补上新增数让账算得平：A - 下架 + 新增 = B
      const lines = [`**🏬 ${name}**`, `📉 在售商品下架 ${delisted.length} 个（在售 ${Object.keys(prevMap).length} → ${items.length}${added ? `，同期新增上架 ${added} 个` : ''}）:`,
        ...itemLines(its, null), '', `_检查时间：${new Date().toLocaleString('zh-CN')}_`];
      const r = await sendFeishu(cfg.webhook, '🔔 Temu 店铺监测告警', lines);
      await chrome.storage.local.set({ lastAlert: { ts: Date.now(), ok: r.ok, msg: r.msg, store: name, lines } });
    }
  } else {
    log.info('First onSale baseline: store=' + name + ' items=' + items.length);
  }
  // 串行写 snapshot，避免盖掉 traffic alerted / slotTrafficMap
  await updateStoreSnapshot(name, { onSaleIds: newMap, onSaleIdsTs: Date.now() });
  return delistedCount;
}

// 假店名（颜色/规格）黑名单——与 content.js 同步，双重防护
// 历史污染：Beige/Black/Charcoal/Grey/Rustic Brown/White Grey/Black Grey 等被误建成「店」
const FAKE_STORE_WORDS = /^(black|white|grey|gray|beige|brown|charcoal|red|blue|green|pink|purple|yellow|orange|gold|silver|ivory|cream|navy|olive|tan|khaki|maroon|coral|mint|teal|cyan|magenta|wine|rose|nude|camel|sand|stone|rustic|dark|light|natural|clear|multi|assorted|random|one size|os|xs|s|m|l|xl|xxl|xxxl|sku|skc|spu|usd|cny|eur|gbp|new|beta|seller|central|best|english|chinese|all|more|less|edit|save|submit|cancel|close|next|prev|back|home|cart|account|login|sign|menu|search|help|support|local|warehouse|free|shipping|sale|off|pack|size|color|colour|style|qty|quantity|option|select)$/i;
function isFakeStoreName(t) {
  if (!t) return true;
  const s = String(t).trim();
  if (s.length < 2 || s.length > 30) return true;
  if (/^[A-Z0-9]+$/.test(s)) return true;
  if (/^(Seller Central|Beta|NEW|SKC|SKU|USD|Best Seller|当前店铺)$/i.test(s)) return true;
  const words = s.split(/\s+/);
  if (words.every((w) => FAKE_STORE_WORDS.test(w))) return true;
  if (words.length === 1 && FAKE_STORE_WORDS.test(words[0])) return true;
  return false;
}
// 解析店铺名：优先页面读到的真店名；拒绝颜色/规格假名；读不到才回退
async function resolveStore(msgStore) {
  if (msgStore && String(msgStore).trim()) {
    const n = String(msgStore).trim();
    if (!isFakeStoreName(n)) return n;
    log.warn('Rejected fake store name: ' + n);
  }
  // 回退：仅当 storage 里只有 1 个真店时用它；否则用配置名；再否则 null（调用方跳过写入）
  const stores = await getStores();
  const known = Object.keys(stores).filter((n) => n && !isFakeStoreName(n));
  if (known.length === 1) return known[0];
  const cfg = await getConfig();
  if (cfg.storeName && cfg.storeName.trim() && !isFakeStoreName(cfg.storeName)) return cfg.storeName.trim();
  return null;
}
// 启动/重载时清掉历史误建的假店
async function cleanupFakeStores() {
  const fake = await withStores(async () => {
    const stores = await getStores();
    const names = Object.keys(stores).filter(isFakeStoreName);
    if (!names.length) return [];
    for (const n of names) delete stores[n];
    await saveStores(stores);
    return names;
  });
  if (!fake.length) return;
  // 同步清 productUrls 里挂在假店下的链接（挪不了，直接丢）
  const cfg = await getConfig();
  if (cfg.productUrls) {
    let changed = false;
    for (const n of fake) {
      if (cfg.productUrls[n]) { delete cfg.productUrls[n]; changed = true; }
    }
    if (changed) await chrome.storage.local.set({ config: cfg });
  }
  log.warn('Cleaned up fake stores: ' + fake.join(', '));
}

// ---------------- 消息处理 ----------------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
    if (msg.type === 'log') {
      if (msg.entry && msg.entry.ts && msg.entry.level) {
        TemuLogger._writeEntry(msg.entry);
      }
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === 'capture') {
      const name = await resolveStore(msg.store);
      if (!name) {
        log.warn('Capture skipped: unresolved store (kind=' + msg.kind + ' raw=' + (msg.store || 'null') + ')');
        sendResponse({ ok: true, skipped: true });
        return;
      }
      log.info('Capture: kind=' + msg.kind + ' store=' + name);
      if (msg.kind === 'countStatus') {
        const p = parseCountStatus(msg.body);
        if (p && p.onSale != null) {
          await updateStoreLatest(name, { onSale: p.onSale, unpublished: p.unpublished, removed: p.removed, deleted: p.deleted });
          await diffAndAlert(name);
        }
      } else if (msg.kind === 'pageQuery') {
        const p = parsePageQuery(msg.body);
        if (p) {
          // 保存一份精简样本，便于排障（不是整页 body，只前 2 个多 SKU 商品）
          try {
            const sample = (p.multiSkuProducts || []).slice(0, 2).map((pr) => ({
              productId: pr.productId, name: pr.name, skuCount: pr.skuCount,
              skus: (pr.skus || []).map((s) => ({ skuId: s.skuId, name: s.name })),
            }));
            await chrome.storage.local.set({
              lastPageSkuSample: {
                store: name, total: p.total, pageSkuCount: p.pageSkuCount,
                productCount: (p.products || []).length,
                multiSkuCount: (p.multiSkuProducts || []).length,
                sample, ts: Date.now(),
              },
            });
          } catch (e) { /* ignore */ }
          log.info('pageQuery SKU: store=' + name
            + ' products=' + (p.products || []).length
            + ' skus=' + p.pageSkuCount
            + ' multiSku=' + (p.multiSkuProducts || []).length);
          // 合并货号 map（跨页保留）——在 withStores 内读旧 map，避免并发丢字段
          await withStores(async () => {
            const prevStores = await getStores();
            const s0 = prevStores[name] || { latest: {}, snapshot: {} };
            const prevMap = (s0.latest && s0.latest.productSkuCodeMap) || {};
            const productSkuCodeMap = Object.assign({}, prevMap, buildProductSkuCodeMap(p.products));
            s0.latest = Object.assign({}, s0.latest, {
              total: p.total,
              pageProducts: p.products,
              pageSkus: p.pageSkus,
              pageSkuCount: p.pageSkuCount,
              multiSkuProducts: p.multiSkuProducts,
              productSkuCodeMap: productSkuCodeMap,
              ts: Date.now(),
            });
            prevStores[name] = s0;
            await saveStores(prevStores);
          });
          // 同 product 内 SKU 消失检测（仅对比本页再次出现的商品，避免分页假下架）
          await diffProductSkus(name, p.products || []);
        }
      } else if (msg.kind === 'skuSpecList') {
        // 始终保存原始响应便于排障（成功/失败都存）
        await chrome.storage.local.set({ lastSkuSpecRaw: msg.body.slice(0, 3000) });
        const p = parseSkuSpecList(msg.body);
        if (p) {
          log.info('skuSpecList captured: store=' + name + ' count=' + p.skuSpecCount);
          await updateStoreLatest(name, { skuSpecs: p.skuSpecs, skuSpecCount: p.skuSpecCount });
        } else {
          log.warn('skuSpecList parse FAILED for store=' + name + ' — raw saved to lastSkuSpecRaw');
        }
      } else if (msg.kind === 'skuPriceQuery') {
        const p = parseSkuPriceQuery(msg.body);
        if (p) {
          log.info('skuPriceQuery captured: store=' + name);
          await updateStoreLatest(name, { skuPriceRaw: p.skuPriceRaw });
        }
      }
      sendResponse({ ok: true });
      return;
    }
    // ---- 前台商品页 variant 监控 ----
    if (msg.type === 'frontCapture') {
      const d = msg.data;
      if (!d || !d.url) { sendResponse({ ok: false, msg: 'invalid data' }); return; }
      log.info('FrontCapture: url=' + d.url + ' title=' + (d.title || '').slice(0, 30) + ' variants=' + d.totalOptions + ' avail=' + d.availableOptions);
      const cfg = await getConfig();
      const productUrls = cfg.productUrls || {};
      let store = null;
      for (const [s, urls] of Object.entries(productUrls)) {
        if (Array.isArray(urls) && urls.some((u) => {
          const a = String(u || '').split('?')[0]; const b = String(d.url || '').split('?')[0];
          return a === b || (d.fullUrl && a === String(d.fullUrl).split('?')[0]);
        })) { store = s; break; }
      }
      if (!store) {
        const known = Object.keys(await getStores()).filter((n) => n && !isFakeStoreName(n));
        store = known.find((n) => (d.fullUrl || d.url).toLowerCase().includes(n.toLowerCase())) || null;
      }
      if (!store) { sendResponse({ ok: false, msg: 'URL not configured for any store' }); return; }
      const key = d.url;
      const { changes } = await withStores(async () => {
        const stores = await getStores();
        const s = stores[store] || { latest: {}, snapshot: {} };
        if (!s.frontLatest) s.frontLatest = {};
        if (!s.frontSnapshot) s.frontSnapshot = {};
        const prev = s.frontLatest[key];
        s.frontLatest[key] = { title: d.title, price: d.price, variants: d.variants, totalOptions: d.totalOptions,
          availableOptions: d.availableOptions, fullUrl: d.fullUrl, ts: Date.now() };
        const ch = [];
        if (prev && prev.variants && d.variants) {
          for (const g of d.variants) {
            const prevG = (prev.variants || []).find((pg) => pg.group === g.group);
            if (!prevG) continue;
            const prevNames = new Set((prevG.options || []).filter((o) => !o.disabled).map((o) => o.name));
            const currNames = new Set((g.options || []).filter((o) => !o.disabled).map((o) => o.name));
            const added = [...currNames].filter((n) => !prevNames.has(n));
            const removed = [...prevNames].filter((n) => !currNames.has(n));
            if (added.length) ch.push('➕ ' + g.group + ' 新增：' + added.join('、'));
            if (removed.length) ch.push('❌ ' + g.group + ' 下架/缺货：' + removed.join('、'));
          }
          if (prev.price && d.price && prev.price !== d.price) {
            ch.push('💰 价格变化：' + prev.price + ' → ' + d.price);
          }
        } else if (prev) {
          log.info('FrontSnapshot first diff baseline: store=' + store + ' url=' + key);
        }
        s.frontSnapshot[key] = Object.assign({}, s.frontLatest[key]);
        stores[store] = s;
        await saveStores(stores);
        return { changes: ch };
      });
      if (changes.length > 0) {
        log.info('FrontAlert: store=' + store + ' url=' + key + ' changes=' + changes.length);
        const lines = ['**🏬 ' + store + ' 前台变体变化**',
          '商品：[' + (d.title || key) + '](' + (d.fullUrl || key) + ')',
          '', ...changes, '',
          '_检测时间：' + new Date().toLocaleString('zh-CN') + '_'];
        const r = await sendFeishu(cfg.webhook, '🔔 Temu 前台变体监测', lines, 'orange');
        await chrome.storage.local.set({ lastFrontAlert: { ts: Date.now(), ok: r.ok, store, url: key, changes } });
      }
      sendResponse({ ok: true, store, changes });
      return;
    }
    if (msg.type === 'addProductUrl') {
      const name = (msg.store || '').trim();
      const url = (msg.url || '').trim();
      if (!name || !url) { sendResponse({ ok: false, msg: '店铺名和链接不能为空' }); return; }
      const cfg = await getConfig();
      const productUrls = Object.assign({}, cfg.productUrls || {});
      if (!productUrls[name]) productUrls[name] = [];
      const base = url.split('?')[0];
      if (!productUrls[name].includes(base)) {
        productUrls[name].push(base);
        cfg.productUrls = productUrls;
        await chrome.storage.local.set({ config: cfg });
        log.info('ProductUrl added: store=' + name + ' url=' + base);
        sendResponse({ ok: true, msg: '已添加', url: base });
      } else {
        sendResponse({ ok: false, msg: '该链接已存在' });
      }
      return;
    }
    if (msg.type === 'deleteProductUrl') {
      const name = (msg.store || '').trim();
      const url = (msg.url || '').trim();
      const cfg = await getConfig();
      const productUrls = Object.assign({}, cfg.productUrls || {});
      if (productUrls[name]) {
        productUrls[name] = productUrls[name].filter((u) => u !== url);
        if (!productUrls[name].length) delete productUrls[name];
        cfg.productUrls = productUrls;
        await chrome.storage.local.set({ config: cfg });
        await withStores(async () => {
          const stores = await getStores();
          const s = stores[name];
          if (s) {
            if (s.frontLatest && s.frontLatest[url]) delete s.frontLatest[url];
            if (s.frontSnapshot && s.frontSnapshot[url]) delete s.frontSnapshot[url];
            await saveStores(stores);
          }
        });
        log.info('ProductUrl deleted: store=' + name);
        sendResponse({ ok: true, msg: '已删除' });
      } else { sendResponse({ ok: false, msg: '店铺不存在' }); }
      return;
    }
    if (msg.type === 'checkFrontNow') {
      const { store, url } = msg;
      if (!url) { sendResponse({ ok: false, msg: 'URL 不能为空' }); return; }
      log.info('FrontCheck manual: store=' + store + ' url=' + url);
      let tab = null;
      try {
        const tabs = await chrome.tabs.query({ url: 'https://www.temu.com/*' });
        tab = tabs.find((t) => {
          return ((t.url || '').split('?')[0]) === ((url || '').split('?')[0]);
        }) || null;
      } catch (e) {}
      if (tab) {
        const r = await sendTabRetry(tab.id, { cmd: 'frontCheck' }, 5);
        sendResponse(r ? { ok: true, msg: '已触发检查' } : { ok: false, msg: '无法与页面通信，请刷新后重试' });
      } else {
        try {
          const newTab = await chrome.tabs.create({ url, active: false });
          await sleep(8000);
          const stores2 = await getStores();
          const ss = stores2[store];
          const key = (url || '').split('?')[0];
          const got = ss && ss.frontLatest && ss.frontLatest[key];
          try { await chrome.tabs.remove(newTab.id); } catch (e) {}
          if (got) {
            sendResponse({ ok: true, msg: '已捕获：' + (got.title || key).slice(0, 40) + '，' + got.totalOptions + ' 个变体' });
          } else {
            sendResponse({ ok: false, msg: '未能提取变体（可能是反爬拦截）。请手动打开商品页后再试。' });
          }
        } catch (e) {
          sendResponse({ ok: false, msg: '打开页面失败：' + (e && e.message || '') });
        }
      }
      return;
    }
    if (msg.type === 'cycleFrontNow') {
      log.info('Manual front cycle requested');
      sendResponse({ ok: true, msg: '前台变体轮巡已启动' });
      cycleFrontProducts('manual'); // fire-and-forget，不阻塞 sendResponse
      return;
    }
    if (msg.type === 'chipStats') {
      const patch = {};
      if (typeof msg.trafficWatch === 'number') patch.trafficWatch = msg.trafficWatch;
      if (typeof msg.trafficDecline === 'number') patch.trafficDecline = msg.trafficDecline;
      if (Array.isArray(msg.watchItems)) patch.watchItems = msg.watchItems;
      if (Array.isArray(msg.declineItems)) patch.declineItems = msg.declineItems;
      if (Object.keys(patch).length) {
        const name = await resolveStore(msg.store);
        if (!name) {
          log.warn('ChipStats skipped: unresolved store (raw=' + (msg.store || 'null') + ')');
        } else {
          // 串行：补全货号 + 空明细不覆盖已有（切店/表格未渲染完会先报空数组）
          await withStores(async () => {
            const storesNow = await getStores();
            const sNow = storesNow[name] || { latest: {}, snapshot: {} };
            const prevL = sNow.latest || {};
            const codeMap = prevL.productSkuCodeMap || {};
            if (Array.isArray(patch.watchItems)) {
              if (patch.watchItems.length) {
                patch.watchItems = enrichWithPageCodes(patch.watchItems, codeMap);
              } else if (Array.isArray(prevL.watchItems) && prevL.watchItems.length
                && !(typeof patch.trafficWatch === 'number' && patch.trafficWatch === 0)) {
                // chip 仍 >0 或未知时，空明细视为未扫全，保留旧清单
                delete patch.watchItems;
              }
            }
            if (Array.isArray(patch.declineItems)) {
              if (patch.declineItems.length) {
                patch.declineItems = enrichWithPageCodes(patch.declineItems, codeMap);
              } else if (Array.isArray(prevL.declineItems) && prevL.declineItems.length
                && !(typeof patch.trafficDecline === 'number' && patch.trafficDecline === 0)) {
                delete patch.declineItems;
              }
            }
            log.info('ChipStats: store=' + name
              + ' trafficWatch=' + (msg.trafficWatch != null ? msg.trafficWatch : 'null')
              + ' trafficDecline=' + (msg.trafficDecline != null ? msg.trafficDecline : 'null')
              + ' watch=' + (patch.watchItems ? patch.watchItems.length : 'keep')
              + ' decline=' + (patch.declineItems ? patch.declineItems.length : 'keep'));
            sNow.latest = Object.assign({}, prevL, patch, { ts: Date.now() });
            storesNow[name] = sNow;
            await saveStores(storesNow);
          });
          await diffAndAlert(name);
        }
      }
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === 'getStatus') {
      sendResponse({
        bgVersion: 'v17-切店去重',
        config: await getConfig(),
        stores: await getStores(),
        ...(await chrome.storage.local.get(['lastAlert', 'lastCycle', 'lastMustRemind', 'lastFrontCycle', 'lastPageSkuSample', 'lastSkuSpecRaw', 'lastSkuSpecRawFail'])),
      });
      return;
    }
    if (msg.type === 'addStore') {
      const name = (msg.name || '').trim();
      log.info('Add store: ' + name);
      if (!name) { sendResponse({ ok: false, msg: '店铺名不能为空' }); return; }
      if (isFakeStoreName(name)) { sendResponse({ ok: false, msg: '「' + name + '」看起来像颜色/规格名，不是店铺名' }); return; }
      const added = await withStores(async () => {
        const stores = await getStores();
        if (stores[name]) return false;
        stores[name] = { latest: {}, snapshot: {} };
        await saveStores(stores);
        return true;
      });
      if (!added) { sendResponse({ ok: false, msg: '「' + name + '」已存在' }); return; }
      sendResponse({ ok: true, msg: '已添加「' + name + '」，下次轮巡将尝试切到该店抓数' });
      return;
    }
    if (msg.type === 'deleteStore') {
      const name = (msg.name || '').trim();
      log.info('Delete store: ' + name);
      const deleted = await withStores(async () => {
        const stores = await getStores();
        if (!stores[name]) return false;
        delete stores[name];
        await saveStores(stores);
        return true;
      });
      if (!deleted) { sendResponse({ ok: false, msg: '「' + name + '」不存在' }); return; }
      sendResponse({ ok: true, msg: '已删除「' + name + '」' });
      return;
    }
    if (msg.type === 'checkNow') {
      log.info('Manual check requested');
      sendResponse(await pollNow());
      return;
    }
    if (msg.type === 'cycleNow') {
      log.info('Manual cycle requested');
      sendResponse(await cycleStores('manual'));
      return;
    }
    if (msg.type === 'testFeishu') {
      log.info('Test Feishu requested');
      const cfg = await getConfig();
      const r = await sendFeishu(cfg.webhook, '✅ Temu 监测测试', ['这是一条测试消息，收到说明飞书配置正常。', '', `_${new Date().toLocaleString('zh-CN')}_`], 'green');
      sendResponse(r);
      return;
    }
    if (msg.type === 'mustRemindNow') {
      log.info('Manual mustRemind requested');
      sendResponse(await sendMustRemind('手动'));
      return;
    }
    } catch (e) {
      log.error('Message handler error: ' + (e && e.message ? e.message : String(e)));
      sendResponse({ ok: false, msg: 'Internal error' });
    }
  })();
  return true;
});

// ---------------- 自动轮巡（切遍每个店抓数，再切回原店；仅空闲时触发） ----------------
const IDLE_SECONDS = 240; // 无操作 4 分钟视为空闲
let cycling = false;

async function getGoodsTab() {
  const tabs = await chrome.tabs.query({ url: 'https://agentseller.temu.com/*' });
  return tabs.find((t) => /goods\/list/.test(t.url || '')) || tabs[0] || null;
}
function sendTab(tabId, cmd) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, cmd, (resp) => {
        if (chrome.runtime.lastError) resolve(null); else resolve(resp);
      });
    } catch (e) { resolve(null); }
  });
}
async function sendTabRetry(tabId, cmd, tries) {
  for (let i = 0; i < (tries || 8); i++) {
    const r = await sendTab(tabId, cmd);
    if (r) return r;
    await new Promise((res) => setTimeout(res, 1000)); // 页面重载后 content 未就绪，重试
  }
  return null;
}
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
// 等某店在切换后被重新抓到（latest.ts 比切换前更新、且有 onSale）
async function waitForStoreCapture(name, sinceTs, timeout) {
  const t0 = Date.now();
  while (Date.now() - t0 < (timeout || 25000)) {
    const stores = await getStores();
    const L = stores[name] && stores[name].latest;
    if (L && typeof L.onSale === 'number' && (L.ts || 0) > sinceTs) return true;
    await sleep(1500);
  }
  return false;
}

async function cycleStores(reason) {
  if (cycling) return { ok: false, msg: '轮巡进行中' };
  cycling = true;
  log.info('Cycle started: reason=' + reason);
  const cycleLog = [];
  try {
    const tab = await getGoodsTab();
    if (!tab) { log.warn('Cycle: no goods tab found'); return { ok: false, msg: '没有打开的 Temu 商品页' }; }
    const cur = await sendTabRetry(tab.id, { cmd: 'ping' }, 5);
    const original = cur && cur.store;
    cycleLog.push('当前店：' + (original || '未知'));

    // 店铺清单：合并「已知店」（顶栏记下 / 面板手动添加）+ 弹窗探测。
    // 过滤假店名（颜色/规格被误读写进 storage 的）
    const known = Object.keys(await getStores()).filter((n) => n && !isFakeStoreName(n));
    let listedNames = [];
    // 已知已够 2 家仍可跳过探测；只有 1 家时必须探测，否则永远单店
    if (known.length < 2) {
      const listed = await sendTabRetry(tab.id, { cmd: 'listStores' }, 5);
      listedNames = (listed && listed.names) || [];
    }
    const names = [...new Set([...known, ...listedNames])].filter(Boolean);
    cycleLog.push(
      known.length >= 2
        ? ('店铺(已知)：' + names.join(', '))
        : ('店铺(已知' + known.length + '+探测' + listedNames.length + ')：' + names.join(', '))
    );
    if (known.length < 2 && listedNames.length === 0) {
      cycleLog.push('提示：可在面板「添加店铺」填 HomeCove / Twilight Cove 等，或手动切到各店一次');
    }
    if (names.length === 0) { log.warn('Cycle: no stores identified'); return { ok: false, msg: '没识别到店铺清单' }; }
    log.info('Cycle stores: ' + names.length + ' stores: ' + names.join(', '));

    // 只有当前这一家店：不要打开切店弹窗（旧逻辑会 switchTo 原店，弹窗卡在页面上）
    const others = names.filter((n) => n && n !== original);
    if (others.length === 0) {
      cycleLog.push('仅 1 家店，跳过切店');
      log.info('Cycle: single store, skip switching');
      const summary = cycleLog.join(' | ');
      log.info('Cycle completed: ' + summary);
      await chrome.storage.local.set({ lastCycle: { ts: Date.now(), reason, summary } });
      return { ok: true, msg: summary };
    }

    for (const name of others) {
      const since = Date.now();
      const r = await sendTabRetry(tab.id, { cmd: 'switchTo', target: name }, 5);
      if (!r || !r.ok) { log.warn('Cycle switch FAILED: store=' + name); cycleLog.push('切到 ' + name + ' 失败：' + (r && r.msg)); continue; }
      const got = await waitForStoreCapture(name, since, 25000);
      cycleLog.push((got ? '✓ ' : '✗ ') + name);
      if (got) {
        log.info('Cycle captured: store=' + name);
      } else {
        log.warn('Cycle capture TIMEOUT: store=' + name);
      }
      // v14：默认不再扫在售清单做下架点名（服务器赛狐负责）。DELIST_IN_PLUGIN 仅应急重开。
      if (DELIST_IN_PLUGIN && got) {
        const os = await sendTabRetry(tab.id, { cmd: 'scanOnSale' }, 3);
        if (os && os.msg) log.warn('scanOnSale aborted: store=' + name + ' ' + os.msg);
        if (os && Array.isArray(os.items)) { const d = await diffOnSale(name, os.items, os.onSaleTabCount, os.store); if (d) { log.warn('Cycle delisted: store=' + name + ' count=' + d); cycleLog.push('  ↳下架' + d + '个'); } }
      }
    }
    // 切回原店（已在原店则跳过，避免再弹一次「切换店铺」）
    if (original) {
      const curNow = await sendTabRetry(tab.id, { cmd: 'ping' }, 3);
      if (curNow && curNow.store === original) {
        cycleLog.push('已在原店 ' + original);
      } else {
        const since = Date.now();
        await sendTabRetry(tab.id, { cmd: 'switchTo', target: original }, 5);
        const gotBack = await waitForStoreCapture(original, since, 25000);
        if (DELIST_IN_PLUGIN && gotBack) {
          const os = await sendTabRetry(tab.id, { cmd: 'scanOnSale' }, 3);
          if (os && os.msg) log.warn('scanOnSale aborted: store=' + original + ' ' + os.msg);
          if (os && Array.isArray(os.items)) { const d = await diffOnSale(original, os.items, os.onSaleTabCount, os.store); if (d) cycleLog.push('  ↳' + original + '下架' + d + '个'); }
        }
        cycleLog.push('已切回 ' + original);
      }
    }
    const summary = cycleLog.join(' | ');
    log.info('Cycle completed: ' + summary);
    await chrome.storage.local.set({ lastCycle: { ts: Date.now(), reason, summary } });
    return { ok: true, msg: summary };
  } catch (e) {
    log.error('Cycle error: ' + (e && e.message ? e.message : String(e)));
    throw e;
  } finally { cycling = false; }
}

async function pollNow() {
  log.info('Poll: reloading goods list page');
  const tab = await getGoodsTab();
  if (!tab) { log.warn('Poll: no goods tab found'); return { ok: false, msg: '未找到打开的 Temu 后台标签页，请先登录并打开商品列表页' }; }
  if (/goods\/list/.test(tab.url || '')) { await chrome.tabs.reload(tab.id, { bypassCache: false }); return { ok: true, msg: '已刷新后台商品页' }; }
  await chrome.tabs.update(tab.id, { url: GOODS_URL });
  return { ok: true, msg: '已导航到商品列表页' };
}

// ---------------- 前台商品页变体轮巡 ----------------
let frontCycling = false;
async function cycleFrontProducts(reason) {
  if (frontCycling) { log.info('FrontCycle skipped: already running'); return; }
  frontCycling = true;
  log.info('FrontCycle started: reason=' + reason);
  try {
    const cfg = await getConfig();
    const productUrls = cfg.productUrls || {};
    const allUrls = [];
    for (const [store, urls] of Object.entries(productUrls)) {
      if (!Array.isArray(urls)) continue;
      for (const url of urls) allUrls.push({ store, url });
    }
    if (!allUrls.length) { log.info('FrontCycle: no URLs configured'); return; }
    log.info('FrontCycle: checking ' + allUrls.length + ' URLs across ' + Object.keys(productUrls).length + ' stores');

    let checked = 0;
    for (const { store, url } of allUrls) {
      try {
        let tab = null;
        try {
          const tabs = await chrome.tabs.query({ url: 'https://www.temu.com/*' });
          tab = tabs.find((t) => ((t.url || '').split('?')[0]) === url) || null;
        } catch (e) { /* ignore */ }

        if (tab) {
          log.info('FrontCycle: reusing tab for ' + url.slice(0, 60));
          await sendTabRetry(tab.id, { cmd: 'frontCheck' }, 3);
          await sleep(6000); // 等 content-front 解析+上报
        } else {
          log.info('FrontCycle: opening tab for ' + url.slice(0, 60));
          const newTab = await chrome.tabs.create({ url, active: false });
          await sleep(12000); // 等 SPA 渲染(2.5s) + 解析 + 上报，留足余量
          try { await chrome.tabs.remove(newTab.id); } catch (e) { /* ignore */ }
        }
        checked++;
      } catch (e) {
        log.warn('FrontCycle: error checking ' + url.slice(0, 60) + ': ' + (e && e.message || e));
      }
    }
    log.info('FrontCycle completed: checked=' + checked + '/' + allUrls.length);
    await chrome.storage.local.set({ lastFrontCycle: { ts: Date.now(), reason, checked, total: allUrls.length } });
  } catch (e) {
    log.error('FrontCycle error: ' + (e && e.message ? e.message : String(e)));
  } finally { frontCycling = false; }
}

// 定时：空闲则轮巡所有店，否则不打扰（靠随看随记覆盖当前店）
// 必提醒：每天固定时刻强制发状态汇报（无异常也发）
chrome.alarms.onAlarm.addListener((a) => {
  log.info('Alarm fired: ' + a.name);
  if (a.name === 'poll') {
    chrome.idle.queryState(IDLE_SECONDS, (state) => {
      if (state === 'idle' || state === 'locked') {
        log.info('System idle, starting automatic cycle');
        cycleStores('idle');
      } else {
        log.info('System active, skipping automatic cycle');
      }
    });
    return;
  }
  if (a.name.startsWith(MUST_REMIND_PREFIX)) {
    const slot = a.name.slice(MUST_REMIND_PREFIX.length);
    // chrome.alarms 的 when 是一次性的 → 发完立刻重排下一天同一时刻
    (async () => {
      try {
        await sendMustRemind(slot);
      } catch (e) {
        log.error('MustRemind error: ' + (e && e.message ? e.message : String(e)));
      } finally {
        await setupMustRemindAlarms();
      }
    })();
    return;
  }
  if (a.name === 'frontPoll') {
    log.info('FrontPoll alarm fired');
    cycleFrontProducts('scheduled');
  }
});

async function setupAlarm() {
  await chrome.storage.local.remove('trafficSample'); // 清早期诊断残留
  const cfg = await getConfig();
  await chrome.alarms.clear('poll');
  chrome.alarms.create('poll', { periodInMinutes: Math.max(1, cfg.intervalMinutes || 15) });
  log.info('Alarm set: every ' + cfg.intervalMinutes + 'min, enabled=' + cfg.enabled);
  await setupMustRemindAlarms();
  // 前台变体监测闹钟
  await chrome.alarms.clear('frontPoll');
  const frontHours = Math.max(1, cfg.frontCheckIntervalHours || 3);
  if (cfg.frontCheckEnabled !== false && cfg.productUrls && Object.keys(cfg.productUrls).length) {
    chrome.alarms.create('frontPoll', { periodInMinutes: frontHours * 60 });
    log.info('FrontPoll alarm set: every ' + frontHours + 'h');
  } else {
    log.info('FrontPoll alarm skipped (disabled or no URLs)');
  }
}
chrome.runtime.onInstalled.addListener(() => { log.info('Extension installed/updated, setting up alarm'); setupAlarm(); });
chrome.runtime.onStartup.addListener(() => { log.info('Chrome startup, setting up alarm'); setupAlarm(); });
chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.config) { log.info('Config changed, reconfiguring alarm'); setupAlarm(); } });

log.info('Service worker started');
// SW 被唤醒时：清理历史假店 + 补闹钟
cleanupFakeStores().catch((e) => log.warn('cleanupFakeStores: ' + (e && e.message || e)));
setupAlarm();
